import unittest
import sys
import os

# Add parent directory to path so we can import logic
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from logic.animator import validate_and_clean_code

class TestAnimatorSanitizer(unittest.TestCase):
    def test_valid_basic_code(self):
        code = """
class AlgorithmScene(BaseDSAScene):
    def construct(self):
        node = self.create_node(10, UP)
        self.play(Create(node))
"""
        cleaned = validate_and_clean_code(code)
        self.assertIn("class AlgorithmScene", cleaned)
        self.assertIn("self.create_node", cleaned)

    def test_remove_imports(self):
        code = """
import os
from manim import *
class AlgorithmScene(BaseDSAScene):
    def construct(self):
        os.system('echo dangerous')
        node = self.create_node(10, UP)
"""
        cleaned = validate_and_clean_code(code)
        self.assertNotIn("import os", cleaned)
        self.assertNotIn("from manim import *", cleaned)
        # It allows the rest
        self.assertIn("class AlgorithmScene", cleaned)

    def test_remove_dangerous_kwargs(self):
        code = """
class AlgorithmScene(BaseDSAScene):
    def construct(self):
        l = Line(start=UP, end=DOWN, dash_units=0.5, max_tip_length_to_length_ratio=0.2)
        self.play(Create(l))
"""
        cleaned = validate_and_clean_code(code)
        self.assertNotIn("dash_units", cleaned)
        self.assertNotIn("max_tip_length_to_length_ratio", cleaned)
        self.assertIn("Line(start=UP, end=DOWN)", cleaned) # Should preserve valid args

    def test_remove_dangerous_functions(self):
        code = """
class AlgorithmScene(BaseDSAScene):
    def construct(self):
        eval("print('hack')")
        exec("import sys")
        open("secret.txt", "r")
        self.wait(1)
"""
        cleaned = validate_and_clean_code(code)
        self.assertNotIn("eval", cleaned)
        self.assertNotIn("exec", cleaned)
        self.assertNotIn("open", cleaned)
        self.assertIn("self.wait(1)", cleaned)

if __name__ == '__main__':
    unittest.main()
