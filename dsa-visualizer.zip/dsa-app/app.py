import streamlit as st
import os
import logging
import sys

# Setup logging
logging.basicConfig(filename='app_debug.log', level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

try:
    import google.generativeai as genai
    import openai
    from logic.explainer import explain_code
    from logic.animator import generate_manim_script, render_scene
    logging.info("Imports successful.")
except Exception as e:
    logging.error(f"Import failed: {e}")
    st.error(f"Critical Dependency Error: {e}")
    st.stop()

st.set_page_config(page_title="DSA Visualizer", layout="wide", page_icon="🧩")

# --- Minimalistic CSS ---
st.markdown("""
<style>
    /* Clean font settings */
    .stApp {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }
    
    /* Subtle Title styling */
    .hero-title {
        font-size: 2.5rem;
        font-weight: 700;
        color: #FFFFFF;
        margin-bottom: 0.5rem;
    }
    .hero-subtitle {
        font-size: 1.1rem;
        color: #B0B0B0;
        margin-bottom: 2rem;
    }
    
    /* Simple Card styling for output */
    div[data-testid="stVerticalBlock"] > div[style*="flex-direction: column;"] > div[data-testid="stVerticalBlock"] {
        background-color: #1E1E1E;
        border-radius: 8px;
        padding: 20px;
    }
</style>
""", unsafe_allow_html=True)

# --- Hero Section ---
st.markdown("""
<div>
    <div class="hero-title">DSA Visualizer</div>
    <div class="hero-subtitle">Plain English Explanations + Step-by-Step Animations</div>
</div>
""", unsafe_allow_html=True)

# Sidebar for Setup
with st.sidebar:
    st.header("Settings")
    
    # API Key
    if "GOOGLE_API_KEY" in st.secrets:
        api_key = st.secrets["GOOGLE_API_KEY"]
        st.success("API Key Active")
    else:
        api_key = st.text_input("API Key", type="password", help="Gemini or OpenAI Key")

    # Model Selection
    model_options = [
        "models/gemini-flash-latest", # (Default - Recommended)
        "Auto (Best Flash Model)",
        "models/gemini-2.0-flash", 
        "models/gemini-1.5-flash",
        "models/gemini-1.5-pro",
        "models/gemini-pro",
        "Manual Entry"
    ]
    st.caption("Select Model")
    user_choice = st.selectbox("Model", model_options, label_visibility="collapsed")
    
    model_choice = user_choice # Default
    
    if user_choice == "Manual Entry":
        model_choice = st.text_input("Enter Model ID")
    elif "Auto" in user_choice:
        if api_key:
            try:
                genai.configure(api_key=api_key)
                
                # Find the first available "flash" model
                available_models = [m.name for m in genai.list_models()]
                flash_models = [m for m in available_models if "flash" in m.lower()]
                
                if flash_models:
                    # Sort to try and get 1.5 first if possible, or just take the first one
                    # We prioritize 1.5 as it is often more stable for free tier
                    # EXPLICITLY avoid "gemini-3" if it exists as it has very low quota
                    safe_flash = [m for m in flash_models if "gemini-3" not in m]
                    
                    priority_flash = [m for m in safe_flash if "1.5" in m]
                    
                    if priority_flash:
                        model_choice = priority_flash[0]
                    elif safe_flash:
                        model_choice = safe_flash[0]
                    else:
                        # Fallback if only gemini-3 exists? Unlikely, but just pick first
                        model_choice = flash_models[0]
                    
                    st.info(f"Auto-selected: **{model_choice}**")
                else:
                    st.warning("No 'flash' model found. Using default `models/gemini-1.5-flash`")
                    model_choice = "models/gemini-1.5-flash"
            except Exception as e:
                 st.error(f"Auto-detect failed: {e}")
                 model_choice = "models/gemini-1.5-flash"
        else:
             st.info("Enter API Key to auto-detect models.")
             model_choice = "models/gemini-1.5-flash"
    
    st.divider()
    
    if st.button("Check Connectivity"):
        if not api_key:
            st.error("Enter API key first.")
        else:
            try:
                genai.configure(api_key=api_key)
                # Just list one to verify connection
                models = genai.list_models()
                first_model = next(models).name
                st.success(f"Connected! found: {first_model}")
            except Exception as e:
                st.error(f"Connection failed: {e}")

# Main Layout
col1, col2 = st.columns([1, 1], gap="medium")

with col1:
    st.subheader("Input Code")
    code_input = st.text_area("Source Code", height=400, label_visibility="collapsed", placeholder="Paste your Python/C++/Java code here...")
    
    if st.button("Analyze & Visualize", type="primary", use_container_width=True):
        if not api_key or not code_input:
            st.warning("Please provide both API Key and Code.")
        else:
            # Create a reusable container in col2 to ensure order
            with col2:
                result_container = st.container()
                
                with result_container:
                     # 1. Explanation
                    with st.spinner("Analyzing logic..."):
                        logging.info("Calling explainer...")
                        explanation = explain_code(code_input, api_key, model_choice)
                        
                        if explanation.startswith("Error"):
                            st.error(explanation)
                            st.stop()
                        
                        st.subheader("Explanation")
                        st.markdown(explanation)
                        st.divider()

                    # 2. Animation
                    with st.spinner("Rendering animation using Manim..."):
                        logging.info("Calling animator...")
                        script = generate_manim_script(code_input, api_key, model_choice)
                        
                        if "Error" in script and script.strip().startswith("#"):
                             st.error("Failed to generate valid animation script.")
                             with st.expander("Debug Script"):
                                 st.code(script)
                        else:
                            success, output = render_scene(script)
                            
                            if success:
                                st.subheader("Visualization")
                                st.video("animation.mp4")
                            else:
                                st.error("Rendering Failed")
                                st.code(output, language="text")
