import google.generativeai as genai
import os
import subprocess
import re
import ast
import logging
from .model_selector import generate_with_fallback

# Configure logging
logging.basicConfig(level=logging.INFO)

# --- The "Golden Source" of Manim Compatibility ---
# We inject this base class into every script. It handles all the complex geometry 
# safely, so the AI only needs to call self.create_node(), etc.
BASE_MANIM_LIB = r"""
from manim import *

class BaseDSAScene(Scene):
    def setup(self):
        # Global settings for consistent look
        Text.set_default(font_size=24)
        
    def create_node(self, value, position, color=BLUE, radius=0.4):
        '''Safely creates a node with text.'''
        c = Circle(color=color).set_fill(color, opacity=0.5)
        # Resize circle safely
        c.width = radius * 2
        
        t = Text(str(value), color=WHITE)
        t.move_to(c.get_center())
        
        group = VGroup(c, t)
        group.move_to(position)
        return group
        
    def create_edge(self, node1, node2, color=WHITE, is_curved=False):
        '''Safely connects two nodes. Abstracts away Arrow/Line complexity.'''
        start = node1.get_center()
        end = node2.get_center()
        
        if is_curved:
            # Safe curved arrow using Arc
            return CurvedArrow(start, end, color=color, angle=TAU/4)
        else:
            return Arrow(start, end, color=color, buff=0.4) # buff handles the radius offset!

    def create_array(self, values, start_pos=UP*2):
        '''Creates a row of squares for an array.'''
        squares = VGroup()
        for i, val in enumerate(values):
            s = Square(side_length=0.8, color=WHITE)
            t = Text(str(val))
            cell = VGroup(s, t)
            cell.move_to(start_pos + RIGHT * i * 0.8)
            squares.add(cell)
        return squares
        
    def show_message(self, text_str, duration=1.0):
        '''Displays a temporary message at the bottom.'''
        t = Text(text_str, font_size=32, color=YELLOW).to_edge(DOWN)
        self.play(Write(t))
        self.wait(duration)
        self.play(FadeOut(t))
        
    def highlight_node(self, node, color=RED):
        '''Temporarily highlights a node.'''
        # node is a VGroup(circle, text)
        if hasattr(node, "submobjects") and len(node.submobjects) > 0:
             circle = node[0]
             self.play(circle.animate.set_color(color))
"""

class ManimSanitizer(ast.NodeTransformer):
    """
    AST-based sanitizer to enforce strict safety rules for Manim scripts.
    """
    def __init__(self):
        self.allowed_calls = {
            # Manim Basics
            "Scene", "Construct", "Create", "Write", "FadeOut", "FadeIn", "Wait", "Play", 
            "Text", "Circle", "Square", "Arrow", "Line", "CurvedArrow", "VGroup", "Group",
            "UP", "DOWN", "LEFT", "RIGHT", "ORIGIN", "TAU", "PI", "DEGREES",
            
            # BaseDSAScene Helpers
            "create_node", "create_edge", "create_array", "show_message", "highlight_node",
            
            # Allow basic python builtins logic
            "len", "range", "enumerate", "str", "int", "list", "append", "pop", "insert"
        }
        self.has_dangerous_comp = False

    def visit_Import(self, node):
        # BAN ALL IMPORTS. We inject strict imports.
        return None

    def visit_ImportFrom(self, node):
        # BAN ALL IMPORTS.
        return None

    def visit_Call(self, node):
        # Inspect function calls
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
            if func_name == "open" or func_name == "eval" or func_name == "exec":
                 # Replace dangerous call with a safe string
                 return ast.Constant(value="UNSAFE_CALL_REMOVED")
                 
        if isinstance(node.func, ast.Attribute):
             # check method calls like self.play
             attr_name = node.func.attr
             # logic to check specific unsafe manim kwargs could go here
             
        # Remove dangerous keyword arguments from any call
        new_keywords = []
        for kw in node.keywords:
            if kw.arg not in ["dash_units", "max_tip_length_to_length_ratio", "background_rectangle"]:
                new_keywords.append(kw)
        node.keywords = new_keywords
        
        return self.generic_visit(node)

def validate_and_clean_code(code_str):
    """
    Parses code into AST, removes banned nodes (imports, dangerous calls),
    and removes specific kwarg keys known to break Manim Community.
    """
    try:
        # 1. Parse
        tree = ast.parse(code_str)
        
        # 2. Transform/Clean
        sanitizer = ManimSanitizer()
        cleaned_tree = sanitizer.visit(tree)
        ast.fix_missing_locations(cleaned_tree)
        
        # 3. Validated Source
        cleaned_code = ast.unparse(cleaned_tree)
        return cleaned_code
        
    except SyntaxError as e:
        logging.error(f"Syntax Error in generated code: {e}")
        # Fallback to regex cleaning if AST fails (e.g. partial code)
        return _regex_clean(code_str)
    except Exception as e:
        logging.error(f"AST cleaning failed: {e}")
        return _regex_clean(code_str)

def _regex_clean(code):
    """Fallback cleaner if AST fails."""
    code = re.sub(r'dash_units\s*=\s*[^,)]+,?', '', code)
    code = re.sub(r'max_tip_length_to_length_ratio\s*=\s*[^,)]+,?', '', code)
    code = re.sub(r'background_rectangle\s*=\s*[^,)]+,?', '', code)
    return code

def generate_manim_script(code, api_key, model_choice="gemini-1.5-flash"):
    """
    Generates a Python script using Manim to visualize the given code.
    """
    prompt = f"""
    Role: Expert Manim Animator for Computer Science (DSA).
    
    Task: Write a Python script using the `manim` library to visualize the execution of this algorithm:
    ```python
    {code}
    ```
    
    CONSTRAINT CHECKLIST (CRITICAL):
    1.  [Inheritance] Class MUST be `class AlgorithmScene(BaseDSAScene):`.
    2.  [No Imports] DO NOT write `from manim import *` or `import ...`. I provide them.
    3.  [Helpers] Use `self.create_node(val, pos)`, `self.create_edge(n1, n2)`, `self.show_message(txt)`, `self.highlight_node(n)`.
    4.  [Visuals] Use `self.play(..., run_time=0.5)` for animations. 
    5.  [Safety] DO NOT use complicated kwargs like `dash_units` or `curve_functions`. Keep it simple.
    
    Output Format:
    Return ONLY the Python code for the scene class. No markdown, no explanations.
    """
    
    try:
        # Use our robust model selector
        full_response = generate_with_fallback(prompt, api_key, preferred_model=model_choice)
        
        if not full_response:
             return "# Error: No response from AI models."

        # Cleaning
        content = full_response
        content = re.sub(r'^```python\s*', '', content, flags=re.MULTILINE)
        content = re.sub(r'^```\s*', '', content, flags=re.MULTILINE)
        content = re.sub(r'```$', '', content, flags=re.MULTILINE)
        content = content.strip()
        
        # AST Validation
        try:
             # Just verify it parses and we can clean it
             content = validate_and_clean_code(content)
        except Exception as e:
             logging.warning(f"Validation warning: {e}")

        return content

    except Exception as e:
        return f"# Critical Error generating script: {str(e)}"

def render_scene(script_content, scene_name="AlgorithmScene", output_filename="animation.mp4"):
    """
    Saves the script to a file and runs Manim to render it.
    """
    # Combine the Golden Source with AI logic
    full_script = BASE_MANIM_LIB + "\n" + script_content
    
    script_path = "generated_scene.py"
    with open(script_path, "w") as f:
        f.write(full_script)
    
    # Run Manim command
    # -ql = Quality Low (480p15), -qm (720p30), -qh (1080p60)
    # We use -ql for speed/reliability in validaton
    cmd = ["manim", "-ql", "--media_dir", ".", "--progress_bar", "none", "-o", output_filename, script_path, scene_name]
    
    # CWD is where we are running
    if os.path.exists(output_filename):
        try:
            os.remove(output_filename)
            logging.info(f"Deleted old output file: {output_filename}")
        except Exception as e:
            logging.warning(f"Could not delete old output file: {e}")

    try:
        # Timeout 90s to be safe
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=90)
        
        # Check if file exists
        if os.path.exists(output_filename):
            return True, result.stderr
            
        # Manim output hunting
        # Try finding it in ./videos/generated_scene/480p15/...
        for root, dirs, files in os.walk("."):
             if output_filename in files:
                  import shutil
                  src = os.path.join(root, output_filename)
                  shutil.move(src, output_filename)
                  return True, "Found and moved video."
                  
        return False, "Manim finished but video not found.\n" + result.stderr

    except subprocess.TimeoutExpired:
        return False, "Render timed out (90s)."
    except subprocess.CalledProcessError as e:
        return False, f"Manim Error:\n{e.stderr}"
    except Exception as e:
        return False, f"System Error: {str(e)}"
