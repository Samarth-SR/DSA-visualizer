from .model_selector import generate_with_fallback
import logging

def explain_code(code, api_key, model_choice="gemini-1.5-flash"):
    """
    Generates a plain English explanation of the structure and algorithm of the provided code.
    """
    
    prompt = f"""
    You are an expert Computer Science instructor. 
    Analyze the following code and provide a clear, beginner-friendly explanation.
    
    Code:
    ```
    {code}
    ```
    
    Format your response in Markdown:
    1. **Summary**: A brief 1-2 sentence overview of what the code does.
    2. **Algorithm**: Step-by-step walkthrough of the logic (plain English).
    3. **Complexity**: Time and Space complexity analysis.
    4. **Key Concepts**: Mention any important DSA concepts used (e.g., Two Pointers, DFS, etc.).
    """

    try:
        # Use simple system instruction for clarity
        system_instruction = "You are a helpful CS instructor."
        
        response_text = generate_with_fallback(
            prompt=prompt, 
            api_key=api_key, 
            preferred_model=model_choice,
            system_instruction=system_instruction
        )
        
        return response_text
            
    except Exception as e:
        return f"Error generating explanation: {str(e)}"
