import google.generativeai as genai
import time
import logging
from google.api_core import exceptions

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def get_available_models(api_key):
    """
    Dynamically fetches available models from the API that support content generation.
    Returns a sorted list of model names (prioritizing flash/pro).
    """
    try:
        genai.configure(api_key=api_key)
        models = []
        for m in genai.list_models():
            if 'generateContent' in m.supported_generation_methods:
                models.append(m.name)
        
        # Sort/Prioritize
        # We want gemini-1.5-flash first, then pro, then others.
        def priority_sort(name):
            if "gemini-1.5-flash" in name: return 0
            if "gemini-1.5-pro" in name: return 1
            if "gemini-pro" in name: return 2
            return 99
            
        models.sort(key=priority_sort)
        return models
    except Exception as e:
        logging.error(f"Failed to list models: {e}")
        # Fallback to hardcoded safe defaults if list fails
        return ["models/gemini-1.5-flash", "models/gemini-pro"]

def generate_with_fallback(prompt, api_key, preferred_model="gemini-1.5-flash", system_instruction=None):
    """
    Generates content using Google's Gemini models with a robust fallback mechanism.
    """
    
    # 1. Get VALID models from the API
    available_models = get_available_models(api_key)
    if not available_models:
        raise RuntimeError("No available Gemini models found for this API key.")
        
    logging.info(f"Available models: {available_models}")

    # 2. Build Fallback Chain
    fallback_chain = []
    
    # Try to match preferred model with available ones
    # (Handling the fact that preferred might be "gemini-1.5-flash" but API returns "models/gemini-1.5-flash-001")
    
    # Helper to fuzzy match
    def find_best_match(target):
        for m in available_models:
            if target in m: # e.g. "gemini-1.5-flash" in "models/gemini-1.5-flash-001"
                return m
        return None

    best_match = find_best_match(preferred_model)
    if best_match:
        fallback_chain.append(best_match)
    
    # Add the rest of available models (deduplicated)
    for m in available_models:
        if m not in fallback_chain:
            fallback_chain.append(m)

    # helper for gemini call
    def call_gemini(model_name):
        genai.configure(api_key=api_key)
        
        generation_config = {
            "temperature": 0.2, 
            "top_p": 0.95,
            "top_k": 64,
            "max_output_tokens": 8192,
        }

        if system_instruction:
            model = genai.GenerativeModel(
                model_name=model_name,
                generation_config=generation_config,
                system_instruction=system_instruction
            )
            response = model.generate_content(prompt)
        else:
            model = genai.GenerativeModel(
                model_name=model_name,
                generation_config=generation_config
            )
            response = model.generate_content(prompt)
            
        return response.text

    last_exception = None

    for model_name in fallback_chain:
        try:
            logging.info(f"Attempting generation with model: {model_name}")
            return call_gemini(model_name)
            
        except Exception as e:
            last_exception = e
            logging.warning(f"Error with {model_name}: {e}. Retrying next...")
            time.sleep(1)
            continue

    # If we get here, all models failed
    raise RuntimeError(f"All models failed. Models tried: {fallback_chain}. Last Error: {last_exception}")
