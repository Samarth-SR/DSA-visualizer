
from manim import *

class BaseDSAScene(Scene):
    def setup(self):
        # Global settings for consistent look
        Text.set_default(font_size=24)
        
    def create_node(self, value, position, color=BLUE, radius=0.4):
        '''Safely creates a node with text.'''
        c = Circle(color=color).set_fill(color, opacity=0.5)
        # Resize circle safely
        c.width = radius * 2
        
        t = Text(str(value), color=WHITE)
        t.move_to(c.get_center())
        
        group = VGroup(c, t)
        group.move_to(position)
        return group
        
    def create_edge(self, node1, node2, color=WHITE, is_curved=False):
        '''Safely connects two nodes. Abstracts away Arrow/Line complexity.'''
        start = node1.get_center()
        end = node2.get_center()
        
        if is_curved:
            # Safe curved arrow using Arc
            return CurvedArrow(start, end, color=color, angle=TAU/4)
        else:
            return Arrow(start, end, color=color, buff=0.4) # buff handles the radius offset!

    def create_array(self, values, start_pos=UP*2):
        '''Creates a row of squares for an array.'''
        squares = VGroup()
        for i, val in enumerate(values):
            s = Square(side_length=0.8, color=WHITE)
            t = Text(str(val))
            cell = VGroup(s, t)
            cell.move_to(start_pos + RIGHT * i * 0.8)
            squares.add(cell)
        return squares
        
    def show_message(self, text_str, duration=1.0):
        '''Displays a temporary message at the bottom.'''
        t = Text(text_str, font_size=32, color=YELLOW).to_edge(DOWN)
        self.play(Write(t))
        self.wait(duration)
        self.play(FadeOut(t))
        
    def highlight_node(self, node, color=RED):
        '''Temporarily highlights a node.'''
        # node is a VGroup(circle, text)
        if hasattr(node, "submobjects") and len(node.submobjects) > 0:
             circle = node[0]
             self.play(circle.animate.set_color(color))

class AlgorithmScene(BaseDSAScene):

    def construct(self):
        self.nodes = []
        self.edges = []
        self.node_spacing = 2.5
        self.start_x = -5
        self.show_message('Operation 1: Create SLL (Insert Front x2)')
        self.insert_front('USN01:Alice')
        self.insert_front('USN02:Bob')
        self.show_message('Operation 2: Display and Count Nodes')
        self.display_list()
        self.show_message('Operation 3: Insert Rear')
        self.insert_rear('USN03:Charlie')
        self.show_message('Operation 4: Delete Rear')
        self.delete_rear()
        self.show_message('Operation 5: Insert Front')
        self.insert_front('USN04:David')
        self.show_message('Operation 6: Delete Front')
        self.delete_front()

    def insert_front(self, data):
        shift_anims = []
        for i, node in enumerate(self.nodes):
            new_pos = RIGHT * (self.start_x + (i + 1) * self.node_spacing)
            shift_anims.append(node.animate.move_to(new_pos))
        if shift_anims:
            self.play(*shift_anims, run_time=0.5)
            for edge in self.edges:
                self.remove(edge)
            self.edges = []
        new_node = self.create_node(data, RIGHT * self.start_x)
        self.nodes.insert(0, new_node)
        for i in range(len(self.nodes) - 1):
            edge = self.create_edge(self.nodes[i], self.nodes[i + 1])
            self.edges.append(edge)
        self.play(Wait(), run_time=0.5)

    def insert_rear(self, data):
        for node in self.nodes:
            self.highlight_node(node)
            self.play(Wait(), run_time=0.2)
        new_pos = RIGHT * (self.start_x + len(self.nodes) * self.node_spacing)
        new_node = self.create_node(data, new_pos)
        if self.nodes:
            edge = self.create_edge(self.nodes[-1], new_node)
            self.edges.append(edge)
        self.nodes.append(new_node)
        self.play(Wait(), run_time=0.5)

    def delete_front(self):
        if not self.nodes:
            self.show_message('List Empty')
            return
        target_node = self.nodes[0]
        self.highlight_node(target_node)
        if len(self.edges) > 0:
            self.play(FadeOut(self.edges[0]), run_time=0.5)
            self.edges.pop(0)
        self.play(FadeOut(target_node), run_time=0.5)
        self.nodes.pop(0)
        shift_anims = []
        for i, node in enumerate(self.nodes):
            new_pos = RIGHT * (self.start_x + i * self.node_spacing)
            shift_anims.append(node.animate.move_to(new_pos))
        if shift_anims:
            self.play(*shift_anims, run_time=0.5)
            for edge in self.edges:
                self.remove(edge)
            self.edges = []
            for i in range(len(self.nodes) - 1):
                edge = self.create_edge(self.nodes[i], self.nodes[i + 1])
                self.edges.append(edge)

    def delete_rear(self):
        if not self.nodes:
            self.show_message('List Empty')
            return
        for i in range(len(self.nodes)):
            self.highlight_node(self.nodes[i])
            self.play(Wait(), run_time=0.2)
        target_node = self.nodes[-1]
        if self.edges:
            self.play(FadeOut(self.edges[-1]), run_time=0.5)
            self.edges.pop()
        self.play(FadeOut(target_node), run_time=0.5)
        self.nodes.pop()

    def display_list(self):
        count = len(self.nodes)
        for node in self.nodes:
            self.highlight_node(node)
            self.play(Wait(), run_time=0.3)
        self.show_message(f'Total Nodes in SLL: {count}')
        self.play(Wait(), run_time=1.0)